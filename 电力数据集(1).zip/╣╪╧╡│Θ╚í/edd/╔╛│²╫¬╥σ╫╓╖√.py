import json

# 读取原始的JSONL文件
with open(r'E:\1.relation_extraction\datasets\edd\all\dev.jsonl', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# 处理每一条数据
cleaned_lines = []
for line in lines:
    data = json.loads(line)
    cleaned_text = data['text'].replace('"', '').replace('\t', '').replace('\\t', '')
    data['text'] = cleaned_text
    cleaned_lines.append(json.dumps(data, ensure_ascii=False))

# 将处理后的数据写入新的JSONL文件
with open(r'E:\1.relation_extraction\datasets\dev.jsonl', 'w', encoding='utf-8') as f:
    for line in cleaned_lines:
        f.write(line + '\n')
